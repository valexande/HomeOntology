import nltk
from Web_Search import *
import textdistance

class main_NLP():


    def __init__(self, list_user_objects, list_objects, class_annotator):
        self.list_user_objects = list_user_objects
        self.list_objects = list_objects
        self.class_annotator = class_annotator

    def find_list(self):
        self.list_user_objects = [entity.replace(' ', '_') for entity in self.list_user_objects]
        list_query = []
        for entity in self.list_user_objects:
            annotated_objects = []
            for house_object in self.list_objects:
                if entity in house_object:
                    distance = textdistance.ratcliff_obershelp(entity.replace('_', ' '), house_object.replace('_', ' '))
                    if distance >= 0.7:
                        annotated_objects.append(house_object)
            print(annotated_objects)
            if annotated_objects != []:
                print("Which " + entity + " do you prefer? Give me the number in the list")
                pointer = input()
                list_query.append(annotated_objects[int(pointer) - 1])
            else:
                print("Sorry but I do not have in my KB the entity " + entity + " do you want me to search on the web for it?")
                print("Tell me [y/n], y = yes || n = no")
                web_choice = input()
                list_web_query = []
                if web_choice == "y":
                    list_web_query = self.web_search(entity, self.list_objects)
                    if list_web_query != []:
                        list_query.append(list_web_query)
                    else:
                        if self.class_annotator == "Q":
                            exit()  ####Here I should catch the case where empty list is returned or stop the program
                        else:
                            continue
                else:  ####or send it to main while
                    if self.class_annotator == "Q":
                        print("Then I cannot answer your question! Sorry :)")
                    else:
                        continue
                    exit()
        return list_query

    def find_list_with_condition(self):
        count = ['1 ', '2 ', '3 ', '4 ', '5 ']
        list_query = []
        for entity in self.list_user_objects:
            annotated_objects = []
            for house_objects in self.list_objects:
                for c in count:
                    if entity + c == house_objects:
                        annotated_objects.append(house_objects)
            print(annotated_objects)
            if annotated_objects != []:
                print("Which " + entity + " do you prefer? Give me the number in the list")
                pointer = input()
                list_query.append(annotated_objects[int(pointer) - 1])
            else:
                print("Sorry but I do not have in my KB the entity " + entity + " do you want me to search on the web for it?")
                print("Tell me [y/n], y = yes || n = no")
                web_choice = input()
                list_web_query = []
                if web_choice == "y":
                    list_web_query = self.web_search(entity, self.list_objects)
                    if list_web_query != []:
                        list_query.append(list_web_query)
                    else:
                        exit()
                else:
                    print("Then I cannot answer your question! Sorry :)")
                    exit()

        return list_query

    def web_search(self, entity_web_search, list_objects_help):
        web_results = Web(entity_web_search, list_objects_help)
        return web_results.main_web()