import statistics
f = open('Variance.txt', 'r')

list_median = []
for entity in f.readlines():
    list_median.append(entity)
f.close()

list_median = list_median[0].split(" ")
for entity in range(len(list_median)):
    list_median[entity] = float(list_median[entity])

list_median_new = []
list_median_new = sorted(list_median)


l = len(list_median_new)
print(l)


print(statistics.variance(list_median_new))
"""
pointerA = int(l/2)
pointerB = int(l/2 + 1)
median_odd = (list_median_new[pointerA] + list_median_new[pointerB])/2
print(int(median_odd))

#median_even = list_median_new[13]
#print(int(median_even))
"""




"""
import os
os.chdir("C:/Users/Alex Vasiliadis/Desktop/SoCoLA Dataset/Ontology_Household/Spatial_Instances")

f = open('C:/Users/Alex Vasiliadis/Desktop/SoCoLA Dataset/Ontology_Household/Spatial_Object.txt', 'r')
list_step = []
for entity in f.readlines():
    list_step.append(entity.replace('\n', ' '))
f.close()
print(list_step)


f = open('C:/Users/Alex Vasiliadis/Desktop/SoCoLA Dataset/Ontology_Household/Spatial_Object_New.txt', 'r')
list_step_new = []
for entity in f.readlines():
    list_step_new.append(entity.replace('\n', ' ').replace(' OK Room ', '').replace(' ', ''))
f.close()
print(list_step_new)

list_final = list_step + list_step_new

#while True:
#object_new = input()
for object_new in list_final:
    helper_string = ""
    for entity in list_final:
        if entity == object_new:
            continue
        else:
            helper_string = helper_string + "rdfs:disjointWith :" + entity + '; \n'
    f = open("Disjoint" + object_new + ".txt", 'w')
    f.write(helper_string)
    f.close()
    
"""