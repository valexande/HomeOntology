from nltk.corpus import wordnet as wn
import textdistance

class Action():
    def __init__(self, list_with_actions):
        self.list_with_actions = list_with_actions

    def Remove(self, list_results):
        final_list = []
        for num in list_results:
            if num not in final_list:
                final_list.append(num)
        return final_list

    def find_actions(self):
        list_steps = ['sit ', 'find ', 'putobjback ', 'walk ', 'close ', 'grab ', 'turnto ', 'putback ', 'rinse ',
              'pour ', 'wipe ',
              'shake ', 'type ', 'push ', 'pointat ', 'spit ', 'putin ', 'drop ', 'brush ', 'cover ', 'scrub ',
              'switchon ',
              'drink ', 'open ', 'read ', 'lie ', 'enter ', 'fold ', 'uncover ', 'pull ', 'wash ', 'greet ',
              'standup ',
              'spread ', 'lookat ', 'switchoff ', 'touch ', 'sleep ', 'stretch ', 'soak ', 'leave ', 'eat ',
              'run ', 'squeeze ',
              'dance ', 'plugin ', 'puton ', 'break ', 'write ', 'cut ', 'talk ', 'putoff ', 'unfold ',
              'watch ', 'crawl ',
              'flush ', 'dial ', 'vacuum ', 'sweep ', 'stir ', 'plugout ', 'unwrap ', 'jump ', 'play ',
              'shave ', 'sing ',
              'climb ', 'wrap ', 'wakeup ', 'sew ', 'laugh ', 'throw ', 'call ', 'wait ', 'text ', 'speak ',
              'speak '  ]

        for value in self.list_with_actions:

            syns = wn.synsets(value)
            print(syns)
            verbs = []
            for ent in syns:
                if value not in ent.name():
                    verbs.append(ent.name().replace('.n.', '').replace('.v.', '').replace('.a.', '').replace('.r.', ''))

            list_number_remove = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']


            verbs_mid = []
            for ent in verbs:
                result = ''.join([i for i in ent if not i.isdigit()])
                verbs_mid.append(result)
            verbs_mid = self.Remove(verbs_mid)


            verbs = []
            for entity in list_steps:
                for search in verbs_mid:
                    distance = textdistance.ratcliff_obershelp(entity.replace(' ', ''), search.replace('_', ''))
                    if distance >= 0.6:
                        verbs.append((entity.replace(' ', ''), distance))

            verbs = sorted(verbs, key=lambda x: x[1], reverse=True)
            verbs_mid = []
            for entity in verbs:
                verbs_mid.append(entity[0])
            verbs_mid = self.Remove(verbs_mid)


            return verbs_mid
