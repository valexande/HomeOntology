from SPARQLWrapper import SPARQLWrapper, JSON
import wikipedia
import textdistance

class WebMining():

    def __init__(self, perceived):
        self.perceived = perceived

    def Remove(self, list_results):
        final_list = []
        for num in list_results:
            if num not in final_list:
                final_list.append(num)
        return final_list

    def property_extract(self):

        list_objects = ['dishrack1 ', 'knife5 ', 'chair1 ', 'food_carrot2 ', 'toothbrush1 ', 'centerpiece1 ', \
                        'electrical_outlet2 ', 'closet1 ', 'table1 ', 'sofa1 ', 'groceries1 ', 'computer1 ',
                        'bathroom1 ', \
                        'toy4 ', 'sheets1 ', 'cookingpot3 ', 'coffee_pot1 ', 'toothbrush_holder1 ', 'milk1 ', 'water1 ',
                        'toilet1 ', 'teeth1 ', 'home_office1 ', 'bowl1 ', 'stove1 ', 'hair1 ', 'mouse1 ', 'kitchen1 ',
                        'faucet1 ', 'clothes_jacket1 ', 'bed1 ', 'magazine5 ', 'living_room1 ', 'couch1 ', 'jelly1 ',
                        'food_onion1 ', 'blow_dryer1 ', 'cup1 ', 'table_cloth1 ', 'plate1 ', 'mail1 ', 'kettle1 ',
                        'bedroom1 ', 'cup5 ', 'rag1 ', 'cabinet1 ', 'note_pad1 ', 'cup2 ', 'cookingpot1 ',
                        'television1 ', 'kitchen_cabinet1 ', 'fork2 ', 'book1 ', 'pot1 ', 'cutting_board1 ',
                        'basket_for_clothes1 ', 'remote_control1 ', 'cleaning_solution1 ', 'mail2 ',
                        'clothes_underwear1 ', 'food_bread2 ', 'laptop1 ', 'water_glass1 ', 'toy1 ', 'dish_soap1 ',
                        'napkin1 ', 'sink1 ', 'clothes_shirt1 ', 'glass1 ', 'lighting1 ', 'cat1 ', 'dog1 ',
                        'tooth_paste1 ', 'notes1 ', 'knife1 ', 'food_cereal1 ', 'bathroom_cabinet1 ', 'coffee1 ',
                        'dishwasher1 ', 'cd_player1 ', 'curtain1 ', 'hands_both1 ', 'napkin2 ', 'coffee_cup1 ',
                        'dining_room1 ', 'bag1 ', 'lamp1 ', 'food_turkey1 ', 'fryingpan1 ', 'food_pizza1 ',
                        'dish_soap2 ', 'shampoo1 ', 'microphone1 ', 'document1 ', 'paper1 ', 'light1 ', 'legs_both1 ',
                        'cupboard1 ', 'man1 ', 'brush1 ', 'floor_lamp1 ', 'pantry1 ', 'plate2 ', 'painting2 ',
                        'textbook1 ', 'fridge1 ', 'fork1 ', 'spoon5 ', 'blanket1 ', 'soap1 ', 'electrical_outlet1 ',
                        'shoes1 ', 'coffe_maker1 ', 'knife2 ', 'sponge1 ', 'laundry_detergent4 ', 'phone1 ',
                        'video_game_console1 ', 'mechanical_pencil1 ', 'food_potato1 ', 'wall2 ', 'floor1 ', 'tray1 ',
                        'dough1 ', 'shower1 ', 'keyboard1 ', 'button1 ', 'hairbrush1 ', 'clothes_pants3 ',
                        'cellphone1 ', 'clothes_hat1 ', 'envelope1 ', 'dry_pasta1 ', 'clothes_shirt2 ',
                        'toilet_paper1 ', 'garbage_can1 ', 'pencil1 ', 'dresser1 ', 'spoon2 ', 'shoes5 ',
                        'light_bulb2 ', 'desk1 ', 'ground_coffee1 ', 'microwave1 ', 'wall_clock1 ', 'spoon1 ',
                        'light2 ', 'telephone1 ', 'vacuum_cleaner1 ', 'radio1 ', 'clothes_pants1 ', 'dustpan1 ',
                        'arms_both1 ', 'food_vegetable3 ', 'printer1 ', 'highlighter1 ', 'drawing1 ', 'food_dessert1 ',
                        'washing_machine1 ', 'toy3 ', 'towel1 ', 'cloth_napkin1 ', 'mouthwash1 ', 'lightswitch1 ',
                        'toaster1 ', 'crackers1 ', 'child1 ', 'clothes_dress1 ', 'pen1 ', 'paper2 ', 'entrance_hall1 ',
                        'dirt1 ', 'controller1 ', 'woman1 ', 'coffee_filter1 ', 'kitchen_counter1 ', 'fork3 ',
                        'freezer1 ', 'juice1 ', 'homework1 ', 'trashcan1 ', 'plate3 ', 'plate5 ',
                        'basket_for_clothes2 ', 'bills1 ', 'wine_glass1 ', 'food_cheese2 ', 'food_sugar1 ',
                        'clothes_pants2 ', 'glass3 ', 'folder1 ', 'mirror1 ', 'magazine4 ', 'hanger1 ',
                        'laundry_detergent1 ', 'conditioner1 ', 'remote_control3 ', 'mop_bucket1 ', 'comforter1 ',
                        'mug3 ', 'painting1 ', 'shoes2 ', 'wall1 ', 'food_noodles1 ', 'sheets2 ', 'carpet1 ',
                        'detergent1 ', 'food_bacon1 ', 'bowl2 ', 'placemat1 ', 'drinking_glass1 ', 'plate4 ',
                        'newspaper1 ', 'food_salt1 ', 'spoon4 ', 'alarm_clock1 ', 'notebook1 ', 'address_book1 ',
                        'video_game_controller2 ', 'mug1 ', 'light_bulb1 ', 'cup4 ', 'pillow1 ', 'food_peanut_butter1 ',
                        'chair2 ', 'feet_both1 ', 'toy2 ', 'board_game1 ', 'food_food1 ', 'oven1 ', 'candle1 ',
                        'love_seat1 ', 'clothes_skirt2 ', 'food_butter1 ', 'bathtub1 ', 'mail3 ', 'sauce1 ', 'fork4 ',
                        'eyes_both1 ', 'broom1 ', 'cup3 ', 'coffee_table1 ', 'filing_cabinet1 ', 'stereo1 ',
                        'food_food3 ', 'keys1 ', 'paper_towel1 ', 'pasta1 ', 'food_chicken1 ', 'novel1 ', 'dirt3 ',
                        'food_cheese1 ', 'face1 ', 'dvd_player1 ', 'shoe_rack1 ', 'placemat2 ', 'fly1 ', 'food_donut1 ',
                        'glue1 ', 'mop1 ', 'glass4 ', 'face_soap1 ', 'child2 ', 'document2 ', 'mat1 ', 'pajamas1 ',
                        'wall3 ', 'window1 ', 'button2 ', 'magazine2 ', 'cd1 ', 'clothes_dress2 ', 'picture1 ',
                        'clothes_skirt1 ', 'console1 ', 'colander1 ', 'coffee2 ', 'picture2 ', 'food_vegetable2 ',
                        'document3 ', 'clothes_shirt3 ', 'food_bread1 ', 'scissors1 ', 'water_glass2 ', 'magazine3 ',
                        'duster1 ', 'stove2 ', 'music_stand1 ', 'tea_bag1 ', 'kids_bedroom1 ', 'cleaning_bottle1 ',
                        'bathroom_counter1 ', 'oven_mitts1 ', 'clothes_socks1 ', 'creditcard1 ', 'tape1 ',
                        'instrument_guitar1 ', 'food_vegetable1 ', 'check1 ', 'food_carrot1 ', 'groceries2 ', 'pot2 ',
                        'food_steak1 ', 'chair3 ', 'cards1 ', 'dishrack3 ', 'magazine1 ', 'video_game_controller1 ',
                        'bookshelf1 ', 'table2 ', 'chef_knife1 ', 'book2 ', 'man2 ', 'food_egg1 ', 'facial_cleanser1 ',
                        'iron1 ', 'woman2 ', 'printing_paper1 ', 'curtain2 ', 'drinking_glass2 ', 'piano_bench1 ',
                        'food_food2 ', 'ironing_board1 ', 'food_oatmeal1 ', 'band-aids1 ', 'alcohol1 ', 'notebook2 ',
                        'table_cloth3 ', 'shaving_cream1 ', 'blanket2 ', 'stamp1 ', 'towel2 ', 'coffee_cup4 ',
                        'drying_rack1 ', 'cloth_napkin2 ', 'pillow2 ', 'headset1 ', 'food_rice1 ', 'deck_of_cards1 ',
                        'food_apple1 ', 'foundation1 ', 'cat2 ', 'textbook2 ', 'crayon1 ', 'wine_glass2 ',
                        'food_banana1 ', 'sofa2 ', 'fork5 ', 'document4 ', 'computer2 ', 'bowl3 ', 'after_shave1 ',
                        'book3 ', 'radio2 ', 'sauce_pan1 ', 'purse1 ', 'spectacles1 ', 'ceiling1 ', 'table_cloth2 ',
                        'food_carrot3 ', 'towel3 ', 'tea1 ', 'box1 ', 'television2 ', 'food_hamburger1 ',
                        'electric_shaver1 ', 'food_jam1 ', 'laser_pointer1 ', 'food_fruit1 ', 'shower2 ', 'curtain3 ',
                        'rag2 ', 'blender1 ', 'knife4 ', 'nail_polish1 ', 'slippers1 ', 'lamp3 ', 'painting3 ',
                        'clothes_pants5 ', 'folder2 ', 'toothbrush2 ', 'hairdryer1 ', 'light3 ', 'razor1 ',
                        'hands_right1 ', 'toilet_paper2 ', 'wine1 ', 'diary1 ', 'button3 ', 'washing_machine2 ',
                        'bookmark1 ', 'food_vegetable4 ', 'shampoo2 ', 'nightstand1 ', 'folder4 ', 'folder3 ',
                        'food_vegetable5 ', 'food_carrot4 ', 'glass2 ', 'juice2 ', 'bench1 ', 'comb1 ', 'mousepad1 ',
                        'drawing3 ', 'instrument_piano1 ', 'bowl5 ', 'bed2 ', 'folder5 ', 'food_carrot5 ',
                        'kitchen_cabinet2 ', 'lamp2 ', 'dirt2 ', 'lighter1 ', 'shredder1 ', 'food_snack1 ',
                        'tooth_paste2 ', 'food_pizza2 ', 'food_egg2 ', 'toothbrush4 ', 'knife3 ', 'clothes_underwear2 ',
                        'pot3 ', 'food_lemon1 ', 'arms_right1 ', 'food_egg4 ', 'ice1 ', 'food_fish1 ',
                        'clothes_shirt5 ', 'dresser2 ', 'coffee_cup2 ', 'spoon3 ', 'receipt1 ', 'napkin3 ',
                        'chessboard1 ', 'clothes_dress3 ', 'food_kiwi1 ', 'teeth2 ', 'soap2 ', 'measuring_cup1 ',
                        'coffe_maker3 ', 'box3 ', 'faucet2 ', 'coffee_pot3 ', 'needle1 ', 'clothes_underwear4 ',
                        'toilet2 ', 'box2 ', 'coin3 ', 'food_apple2 ', 'scrabble1 ', 'remote_control2 ',
                        'clothes_socks2 ', 'hands_both3 ', 'coffee_table2 ', 'cleaning_solution2 ', 'oil1 ', 'paper3 ',
                        'box4 ', 'drawing2 ', 'towel_rack1 ', 'toothbrush3 ', 'glass5 ', 'pillow3 ',
                        'instrument_violin1 ', 'clothes_underwear5 ', 'book4 ', 'hands_left1 ', 'paper_towel2 ',
                        'water5 ', 'coffee_pot2 ', 'picture3 ', 'food_noodles2 ', 'clothes_jacket2 ', 'lighting2 ',
                        'food_ice_cream1 ', 'tooth_paste3 ', 'clothes_pants4 ', 'clothes_dress4 ', 'shoe-shine_kit1 ',
                        'clothes_scarf1 ', 'arms_left1 ', 'shoes4 ', 'food_onion2 ', 'basket_for_clothes3 ',
                        'clothes_underwear3 ', 'food_onion3 ', 'napkin4 ', 'fax_machine1 ', 'hands_both2 ', 'mail4 ',
                        'telephone2 ', 'dishwasher2 ', 'coin2 ', 'chair4 ', 'video_game_console2 ', 'food_potato2 ',
                        'thread1 ', 'coin1 ', 'controller2 ', 'mug2 ', 'couch2 ', 'shoes3 ', 'bedroom2 ', 'beer1 ',
                        'homework2 ', 'clothes_socks5 ', 'clothes_socks5 ']
        f = open('Steps_General_Knowledge.txt', 'r')
        for line in f.readlines():
            print(line.replace('\n', ''))
        choice = input()
        if choice == 'a':
            try:
                sparql_not_common_hypernym = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_not_common_hypernym.setQuery(""" PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>
                                                        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                                                        SELECT DISTINCT ?comment WHERE{
                                                        ?entry rdfs:label \"""" + self.perceived.capitalize() + """\"@en. 
                                                        ?entry rdfs:comment ?comment
                                                        FILTER(lang(?comment) = 'en') }
                                                    """)
                sparql_not_common_hypernym.setReturnFormat(JSON)
                results = sparql_not_common_hypernym.query().convert()
                property_preprocess = results['results']['bindings']
                for property in property_preprocess:
                    prp = property['comment']['value']
                    print(prp + "\n")
            except Exception:
                print("You could ask me something else")
                exit()
        elif choice == 'b':
            list_eliminate = ['wikiPageID', 'wikiPageRevisionID', 'wikiPageWikiLink', 'wikiPageExternalLink', 'name', 'thumbnail', 'abstract', 'binomialAuthority',
                              'class', 'division', 'family', 'genus', 'kingdom', 'order', 'synonym', 'betacaroteneUg', 'binomial']
            try:
                sparql_not_common_hypernym = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_not_common_hypernym.setQuery(""" PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>
                                                        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>
                                                        SELECT DISTINCT ?property WHERE{
                                                        ?entry rdfs:label \"""" + self.perceived.capitalize() + """\"@en.
                                                        ?entry ?property ?comment}
                                                    """)
                sparql_not_common_hypernym.setReturnFormat(JSON)
                results = sparql_not_common_hypernym.query().convert()
                property_preprocess = results['results']['bindings']
                list_property = []
                for property in property_preprocess:
                    prp = property['property']['value']
                    if 'dbpedia' in prp:
                        prp = prp.replace('http://dbpedia.org/', '').split("/")
                        list_property.append(prp[1])

                for property in list_eliminate:
                    if property in list_property:
                        list_property.remove(property)
                print("Choose property to return value")
                print(list_property)
                choice = input()
                annotator = list_property[int(choice) - 1]
                sparql_not_common_hypernym = SPARQLWrapper("http://dbpedia.org/sparql")
                sparql_not_common_hypernym.setQuery(""" PREFIX dbpedia-owl: <http://dbpedia.org/ontology/>
                                                        PREFIX rdfs: <http://www.w3.org/2000/01/rdf-schema#>  
                                                        PREFIX dbpedia2: <http://dbpedia.org/property/>
                                                        SELECT DISTINCT ?value WHERE{
                                                        ?entry rdfs:label \"""" + self.perceived.capitalize() + """\"@en.
                                                        ?entry dbpedia2:""" + annotator + """ ?value}
                                                    """)
                sparql_not_common_hypernym.setReturnFormat(JSON)
                results = sparql_not_common_hypernym.query().convert()
                property_preprocess = results['results']['bindings']
                print(annotator)
                for property in property_preprocess:
                    prp = property['value']['value']
                    print(prp + "\n")
            except Exception:
                print("You could ask me something else\n")
                exit()
        elif choice == 'c':
            try:
                wiki_prp = wikipedia.search(self.perceived)

                wiki_proposes = []
                for wiki in wiki_prp:
                    for obj_house in list_objects:
                        distance = textdistance.ratcliff_obershelp(wiki, obj_house.replace('_', '').replace('1 ', '').replace('food ', '').lower())
                        if distance >= 0.5:
                            wiki_proposes.append((wiki, distance))

                wiki_proposes = self.Remove(wiki_proposes)
                print("For " + self.perceived + " I would recommend one of the following:")
                wiki_proposes = sorted(wiki_proposes, key=lambda x: x[1], reverse=True)
                print("Please select one of the following in your search for questions (1)-(9)\n")
                flag_list = []
                for wiki in wiki_proposes:
                    if wiki[0] in flag_list:
                        pass
                    else:
                        print(wiki[0])
            except Exception:
                print("I could not find something")
        else:
            print("Under construction\n")