from Property_Distance_CommentBox import *
import textdistance
from TFIDF_Compiler import *
from Sorted_and_Display import *
from Find_Similarity import *
import requests

class Web():

    def __init__(self, entity, list_objects):
        self.entity = entity
        self.list_objects = list_objects


    def Remove(self,duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def myfunc(self, term):
        return 'http://api.conceptnet.io/c/en/' + term + '?offset=0&limit=1000'

    def main_web(self):
        lst = []
        lst2 = []
        property_values = self.myfunc(self.entity)
        respone = requests.get(property_values)
        obj = respone.json()
        lst0 = []
        for relation in obj['edges']:
            if ('wordnet' in relation['sources'][0]['@id']) or ('verbosity' in relation['sources'][0]['@id']):
                lst0.append(1)
            else:
                lst0.append(0)

        lst = [relation['rel']['@id'] for relation in obj['edges']]
        lst2 = [relation['@id'] for relation in obj['edges']]
        lst3 = [relation['weight'] for relation in obj['edges']]


        list_with_properties = []
        similarity = Find_Similarity_Household(lst2, lst, [self.entity], lst3)
        cleaned_entities_first = similarity.cleaning_entities()
        cleaned_entities_second, weights_of_entities = similarity.cleaning_entities_second(cleaned_entities_first[1], cleaned_entities_first[0])
        cleaned_final, weight_final = similarity.grounding(cleaned_entities_second, weights_of_entities)
        new_cleaned_final, new_weight_final = similarity.strong_related(cleaned_final, weight_final)


        property_distance_comment = prop_dist_comm(new_cleaned_final, [self.entity], new_weight_final)
        comment_boxes_perceived, comment_boxes_common, comment_boxes_not_common = property_distance_comment.relations()


        score_sender = tf_idf(comment_boxes_perceived, comment_boxes_common, comment_boxes_not_common, weight_final)
        final_score_common, final_score_not_common = score_sender.tf_idf_accumulator()

        sorted_final = final_sorting_display(final_score_common, final_score_not_common, self.entity)
        hash_final_sorted = sorted_final.display()
        print("I have found similarities with the ones below")
        print(" ")
        list_for_choice = []
        for property in hash_final_sorted:
            print(self.entity.capitalize() + " is" + property.replace('/r/', ' '), end=" ")
            count_len = len(hash_final_sorted[property])
            count = 0
            for entity in hash_final_sorted[property]:
                if count < count_len - 1:
                    print(entity[0] + ',', end=" ")
                else:
                    print(entity[0] + '.', end=" ")
                count = count + 1
                list_for_choice.append(entity[0])
            print("\n")

        list_capabilities = []
        list_for_choice_helping = []
        for entity in list_for_choice:
            for object in self.list_objects:
                if entity in object:
                    list_capabilities.append(object)
                    list_for_choice_helping.append(entity)
        list_capabilities = self.Remove(list_capabilities)

        list_for_choice_helping = self.Remove(list_for_choice_helping)
        list_choice = []
        if len(list_capabilities) > 1:
            print("Similar objects that I have in my KB are the following. Please give a number in the list to answer your query")
            hash_choice = {}
            hash_pretty_display = {}
            for entity in list_for_choice_helping:
                for obj in list_capabilities:
                    distance = textdistance.ratcliff_obershelp(entity.replace('_', ' '), obj.replace('_', ' ').replace('1 ', '').replace('2 ', '').replace('3 ', '').replace('4 ', '').replace('5 ', ''))
                    if distance >= 0.6:
                        hash_choice[obj] = distance
                        hash_pretty_display[(obj, entity)] = distance
            hash_choice = sorted(hash_choice.items(), key=lambda kv: kv[1], reverse=True)
            hash_pretty_display = sorted(hash_pretty_display.items(), key=lambda kv: kv[1], reverse=True)



            hash_pretty_display_new = {}
            for entity in hash_pretty_display:
                hash_pretty_display_new[entity[0][0]] = entity[0][1]
            list_with_card = []
            for entity in hash_pretty_display_new:
                counter = 0
                ent = hash_pretty_display_new[entity]
                for second_entity in hash_pretty_display_new:
                    if ent == hash_pretty_display_new[second_entity]:
                        counter = counter + 1
                list_with_card.append((ent, counter))
            list_with_card = self.Remove(list_with_card)
            final_list_pretty = []
            for entity in hash_pretty_display:
                cnt = 0
                for ent in list_with_card:
                    if entity[0][1] == ent[0]:
                        cnt = ent[1]
                if cnt > 1:
                    final_list_pretty.append(entity[0][0].replace('_', ' ').replace('1 ', '').replace('food ', ''))
                else:
                    final_list_pretty.append(entity[0][1].replace('_', ' ').replace('1 ', '').replace('food ', ''))
            print(final_list_pretty)
            if len(final_list_pretty) > 0:      ##New needed an extra if
                if self.checkIfDuplicates(final_list_pretty):
                    print("Do you want me to help you with the duplicates")
                    print("Give a yes or no! [y/n]   y = yes || n = no")
                    answer_duplicates = input()
                    final_list_with_duplicates = []
                    if answer_duplicates == "y":
                        for entity in hash_pretty_display:
                            cnt = 0
                            for ent in list_with_card:
                                if entity[0][1] == ent[0]:
                                    cnt = ent[1]
                            if cnt > 1:
                                final_list_with_duplicates.append((entity[0][1].replace('_', ' ').replace('1 ', '').replace('food ', ''), "-->", entity[0][0].replace('_', ' ').replace('1 ', '').replace('food ', '')))
                            else:
                                final_list_with_duplicates.append((entity[0][1].replace('_', ' ').replace('1 ', '').replace('food ', ''), "-->", entity[0][0].replace('_', ' ').replace('1 ', '').replace('food ', '')))
                    print(final_list_with_duplicates)

                final_list = []
                for entity in hash_pretty_display:
                    final_list.append(entity[0][0])
                choice_annotator = input()
                list_choice = final_list[int(choice_annotator) - 1]
                print(list_choice)
            else:               ##Here the otherwise condition
                print("None Unfortunately")
        elif len(list_capabilities) == 1:
            print("I have only found one similar object")
            list_choice = list_capabilities[0]
            print(list_choice)
            print("Do you like it? [y/n]  y = yes || n = no")
            answer_single = input()
            if answer_single == "y":
                pass
            else:
                print("Ask another question")
                exit()
        else:
            print("Sorry even the web could not help me do you want to ask me again about something else")

        return list_choice



    def checkIfDuplicates(self,listOfElems):
        if len(listOfElems) == len(set(listOfElems)):
            return False
        else:
            return True


