from Ontology import *
from SPARQL_Generator import *
from General_Web_Knowledge import *


if __name__ == '__main__':

    while True:
        list_back_up = []
        list_help = ['1', '2', '3', '4', '5', '6', '7', '8', '9']
        f = open("Steps_Objects.txt", "r")
        for line in f.readlines():
            print(line, end=" ")
        print("\n")
        choice = input()
        if choice == "10":
            object_ontology = ontology_household_environment('Alex')
            sparql_results = object_ontology.ontology_parsing()
            print(sparql_results)
            open('SPARQL_Query.txt', 'w').close()
        elif choice in list_help:
            query_processing = parsing(list_back_up, choice)
            query_processing.parsing_module()
            open('SPARQL_Query.txt', 'w').close()
        elif choice == '11':
            print("Give the object for which you want information")
            object = input()
            general_knowledge = WebMining(object)
            general_knowledge.property_extract()
        elif choice == "alex":
            exit()