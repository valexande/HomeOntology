from nltk.corpus import wordnet as wn

class HelpWordNet():

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def __init__(self, Value):
        self.Value = Value

    def list_with_hyponyms(self):
        f = open("Objects.txt", "r")
        list_objects_dirty = []
        for line in f.readlines():
            entity = line.replace("\n", "")
            entity = entity.split("  ")[0]
            list_objects_dirty.append(entity)
        list_objects_dirty = self.Remove(list_objects_dirty)
        f.close()

        Hyponyms = []
        for entity in list_objects_dirty:
            try:
                vehicle = wn.synset(entity + '.n.01')
                Hyponyms = Hyponyms + list(set([w for s in vehicle.closure(lambda s:s.hyponyms()) for w in s.lemma_names()]))
            except Exception:
                Hyponyms = Hyponyms + []
        Hyponyms = Hyponyms + list_objects_dirty
        Hyponyms = self.Remove(Hyponyms)
        return Hyponyms

    def keep_household_objects(self, list_household, entities_ConceptNet):

        list_CN = []
        for property in entities_ConceptNet:
            for entity in entities_ConceptNet[property]:
                list_CN.append(entity)

        household_objects = []
        house1 = []
        house2 = []
        for entity in list_CN:
            word = wn.synsets(entity)
            try:
                hypernym = list(set([w for s in word[0].closure(lambda s: s.hypernyms()) for w in s.lemma_names()]))
                hyponym = list(set([w for s in word[0].closure(lambda s: s.hyponyms()) for w in s.lemma_names()]))
                if hypernym != []:
                    for obj in hypernym:
                        if obj in list_household:
                            house1.append(obj)
                if hyponym != []:
                    for obj in hyponym:
                        if obj in list_household:
                            house2.append(obj)
                household_objects = house1 + house2
            except Exception:
                    exit()
        household_objects = self.Remove(household_objects)

        list_all_help = []
        for entity in household_objects:
            list_help = entity.split("_")
            for ent in list_help:
                list_all_help.append(ent)
        household_objects = household_objects + list_all_help

        return household_objects


    def return_significant(self, household_objects, cn_properties, cn_weights):
        length_weights = len(cn_weights)
        cn_weights_counter = []
        for entity in range(length_weights):
            if cn_weights[entity][0] not in household_objects:
                cn_weights_counter.append(entity)

        cn_weights_new = []         #has the dessired weights
        for counter in range(length_weights):
            if counter not in cn_weights_counter:
                cn_weights_new.append(cn_weights[counter])

        list_properties = []
        for tup in cn_weights_new:
            for entity in cn_properties.items():
                if entity[1] != []:
                    for ent in entity[1]:
                        if ent == tup[0]:
                            list_properties.append((entity[0], ent))
        list_properties = self.Remove(list_properties)

        list_properties_new = []
        check_val = set()  # Check Flag
        for i in list_properties:
            if i[1] not in check_val:
                list_properties_new.append(i)
                check_val.add(i[1])

        hash_household = {}
        for property in list_properties_new:
            if hash_household.get(property[0]) == None:
                hash_household.setdefault(property[0], []).append(property[1])
            else:
                hash_household[property[0]].append(property[1])


        return hash_household, cn_weights_new