from Ontology import *
from Ontology_Object_NLP import *
from Action_Similarity import *
import textdistance

class parsing():

    def __init__(self, back_up, choice):
        self.back_up = back_up
        self.choice = choice

    def Remove(self, list_results):
        final_list = []
        for num in list_results:
            if num not in final_list:
                final_list.append(num)
        return final_list

    def parsing_module(self):
        list_steps = ['sit ', 'find ', 'putobjback ', 'walk ', 'close ', 'grab ', 'turnto ', 'putback ', 'rinse ',
                      'pour ', 'wipe ',
                      'shake ', 'type ', 'push ', 'pointat ', 'spit ', 'putin ', 'drop ', 'brush ', 'cover ', 'scrub ',
                      'switchon ',
                      'drink ', 'open ', 'read ', 'lie ', 'enter ', 'fold ', 'uncover ', 'pull ', 'wash ', 'greet ',
                      'standup ',
                      'spread ', 'lookat ', 'switchoff ', 'touch ', 'sleep ', 'stretch ', 'soak ', 'leave ', 'eat ',
                      'run ', 'squeeze ',
                      'dance ', 'plugin ', 'puton ', 'break ', 'write ', 'cut ', 'talk ', 'putoff ', 'unfold ',
                      'watch ', 'crawl ',
                      'flush ', 'dial ', 'vacuum ', 'sweep ', 'stir ', 'plugout ', 'unwrap ', 'jump ', 'play ',
                      'shave ', 'sing ',
                      'climb ', 'wrap ', 'wakeup ', 'sew ', 'laugh ', 'throw ', 'call ', 'wait ', 'text ', 'speak ',
                      'speak ']
        list_objects = ['dishrack1 ', 'knife5 ', 'chair1 ', 'food_carrot2 ', 'toothbrush1 ', 'centerpiece1 ', \
                        'electrical_outlet2 ', 'closet1 ', 'table1 ', 'sofa1 ', 'groceries1 ', 'computer1 ',
                        'bathroom1 ', \
                        'toy4 ', 'sheets1 ', 'cookingpot3 ', 'coffee_pot1 ', 'toothbrush_holder1 ', 'milk1 ', 'water1 ',
                        'toilet1 ', 'teeth1 ', 'home_office1 ', 'bowl1 ', 'stove1 ', 'hair1 ', 'mouse1 ', 'kitchen1 ',
                        'faucet1 ', 'clothes_jacket1 ', 'bed1 ', 'magazine5 ', 'living_room1 ', 'couch1 ', 'jelly1 ',
                        'food_onion1 ', 'blow_dryer1 ', 'cup1 ', 'table_cloth1 ', 'plate1 ', 'mail1 ', 'kettle1 ',
                        'bedroom1 ', 'cup5 ', 'rag1 ', 'cabinet1 ', 'note_pad1 ', 'cup2 ', 'cookingpot1 ',
                        'television1 ', 'kitchen_cabinet1 ', 'fork2 ', 'book1 ', 'pot1 ', 'cutting_board1 ',
                        'basket_for_clothes1 ', 'remote_control1 ', 'cleaning_solution1 ', 'mail2 ',
                        'clothes_underwear1 ', 'food_bread2 ', 'laptop1 ', 'water_glass1 ', 'toy1 ', 'dish_soap1 ',
                        'napkin1 ', 'sink1 ', 'clothes_shirt1 ', 'glass1 ', 'lighting1 ', 'cat1 ', 'dog1 ',
                        'tooth_paste1 ', 'notes1 ', 'knife1 ', 'food_cereal1 ', 'bathroom_cabinet1 ', 'coffee1 ',
                        'dishwasher1 ', 'cd_player1 ', 'curtain1 ', 'hands_both1 ', 'napkin2 ', 'coffee_cup1 ',
                        'dining_room1 ', 'bag1 ', 'lamp1 ', 'food_turkey1 ', 'fryingpan1 ', 'food_pizza1 ',
                        'dish_soap2 ', 'shampoo1 ', 'microphone1 ', 'document1 ', 'paper1 ', 'light1 ', 'legs_both1 ',
                        'cupboard1 ', 'man1 ', 'brush1 ', 'floor_lamp1 ', 'pantry1 ', 'plate2 ', 'painting2 ',
                        'textbook1 ', 'fridge1 ', 'fork1 ', 'spoon5 ', 'blanket1 ', 'soap1 ', 'electrical_outlet1 ',
                        'shoes1 ', 'coffe_maker1 ', 'knife2 ', 'sponge1 ', 'laundry_detergent4 ', 'phone1 ',
                        'video_game_console1 ', 'mechanical_pencil1 ', 'food_potato1 ', 'wall2 ', 'floor1 ', 'tray1 ',
                        'dough1 ', 'shower1 ', 'keyboard1 ', 'button1 ', 'hairbrush1 ', 'clothes_pants3 ',
                        'cellphone1 ', 'clothes_hat1 ', 'envelope1 ', 'dry_pasta1 ', 'clothes_shirt2 ',
                        'toilet_paper1 ', 'garbage_can1 ', 'pencil1 ', 'dresser1 ', 'spoon2 ', 'shoes5 ',
                        'light_bulb2 ', 'desk1 ', 'ground_coffee1 ', 'microwave1 ', 'wall_clock1 ', 'spoon1 ',
                        'light2 ', 'telephone1 ', 'vacuum_cleaner1 ', 'radio1 ', 'clothes_pants1 ', 'dustpan1 ',
                        'arms_both1 ', 'food_vegetable3 ', 'printer1 ', 'highlighter1 ', 'drawing1 ', 'food_dessert1 ',
                        'washing_machine1 ', 'toy3 ', 'towel1 ', 'cloth_napkin1 ', 'mouthwash1 ', 'lightswitch1 ',
                        'toaster1 ', 'crackers1 ', 'child1 ', 'clothes_dress1 ', 'pen1 ', 'paper2 ', 'entrance_hall1 ',
                        'dirt1 ', 'controller1 ', 'woman1 ', 'coffee_filter1 ', 'kitchen_counter1 ', 'fork3 ',
                        'freezer1 ', 'juice1 ', 'homework1 ', 'trashcan1 ', 'plate3 ', 'plate5 ',
                        'basket_for_clothes2 ', 'bills1 ', 'wine_glass1 ', 'food_cheese2 ', 'food_sugar1 ',
                        'clothes_pants2 ', 'glass3 ', 'folder1 ', 'mirror1 ', 'magazine4 ', 'hanger1 ',
                        'laundry_detergent1 ', 'conditioner1 ', 'remote_control3 ', 'mop_bucket1 ', 'comforter1 ',
                        'mug3 ', 'painting1 ', 'shoes2 ', 'wall1 ', 'food_noodles1 ', 'sheets2 ', 'carpet1 ',
                        'detergent1 ', 'food_bacon1 ', 'bowl2 ', 'placemat1 ', 'drinking_glass1 ', 'plate4 ',
                        'newspaper1 ', 'food_salt1 ', 'spoon4 ', 'alarm_clock1 ', 'notebook1 ', 'address_book1 ',
                        'video_game_controller2 ', 'mug1 ', 'light_bulb1 ', 'cup4 ', 'pillow1 ', 'food_peanut_butter1 ',
                        'chair2 ', 'feet_both1 ', 'toy2 ', 'board_game1 ', 'food_food1 ', 'oven1 ', 'candle1 ',
                        'love_seat1 ', 'clothes_skirt2 ', 'food_butter1 ', 'bathtub1 ', 'mail3 ', 'sauce1 ', 'fork4 ',
                        'eyes_both1 ', 'broom1 ', 'cup3 ', 'coffee_table1 ', 'filing_cabinet1 ', 'stereo1 ',
                        'food_food3 ', 'keys1 ', 'paper_towel1 ', 'pasta1 ', 'food_chicken1 ', 'novel1 ', 'dirt3 ',
                        'food_cheese1 ', 'face1 ', 'dvd_player1 ', 'shoe_rack1 ', 'placemat2 ', 'fly1 ', 'food_donut1 ',
                        'glue1 ', 'mop1 ', 'glass4 ', 'face_soap1 ', 'child2 ', 'document2 ', 'mat1 ', 'pajamas1 ',
                        'wall3 ', 'window1 ', 'button2 ', 'magazine2 ', 'cd1 ', 'clothes_dress2 ', 'picture1 ',
                        'clothes_skirt1 ', 'console1 ', 'colander1 ', 'coffee2 ', 'picture2 ', 'food_vegetable2 ',
                        'document3 ', 'clothes_shirt3 ', 'food_bread1 ', 'scissors1 ', 'water_glass2 ', 'magazine3 ',
                        'duster1 ', 'stove2 ', 'music_stand1 ', 'tea_bag1 ', 'kids_bedroom1 ', 'cleaning_bottle1 ',
                        'bathroom_counter1 ', 'oven_mitts1 ', 'clothes_socks1 ', 'creditcard1 ', 'tape1 ',
                        'instrument_guitar1 ', 'food_vegetable1 ', 'check1 ', 'food_carrot1 ', 'groceries2 ', 'pot2 ',
                        'food_steak1 ', 'chair3 ', 'cards1 ', 'dishrack3 ', 'magazine1 ', 'video_game_controller1 ',
                        'bookshelf1 ', 'table2 ', 'chef_knife1 ', 'book2 ', 'man2 ', 'food_egg1 ', 'facial_cleanser1 ',
                        'iron1 ', 'woman2 ', 'printing_paper1 ', 'curtain2 ', 'drinking_glass2 ', 'piano_bench1 ',
                        'food_food2 ', 'ironing_board1 ', 'food_oatmeal1 ', 'band-aids1 ', 'alcohol1 ', 'notebook2 ',
                        'table_cloth3 ', 'shaving_cream1 ', 'blanket2 ', 'stamp1 ', 'towel2 ', 'coffee_cup4 ',
                        'drying_rack1 ', 'cloth_napkin2 ', 'pillow2 ', 'headset1 ', 'food_rice1 ', 'deck_of_cards1 ',
                        'food_apple1 ', 'foundation1 ', 'cat2 ', 'textbook2 ', 'crayon1 ', 'wine_glass2 ',
                        'food_banana1 ', 'sofa2 ', 'fork5 ', 'document4 ', 'computer2 ', 'bowl3 ', 'after_shave1 ',
                        'book3 ', 'radio2 ', 'sauce_pan1 ', 'purse1 ', 'spectacles1 ', 'ceiling1 ', 'table_cloth2 ',
                        'food_carrot3 ', 'towel3 ', 'tea1 ', 'box1 ', 'television2 ', 'food_hamburger1 ',
                        'electric_shaver1 ', 'food_jam1 ', 'laser_pointer1 ', 'food_fruit1 ', 'shower2 ', 'curtain3 ',
                        'rag2 ', 'blender1 ', 'knife4 ', 'nail_polish1 ', 'slippers1 ', 'lamp3 ', 'painting3 ',
                        'clothes_pants5 ', 'folder2 ', 'toothbrush2 ', 'hairdryer1 ', 'light3 ', 'razor1 ',
                        'hands_right1 ', 'toilet_paper2 ', 'wine1 ', 'diary1 ', 'button3 ', 'washing_machine2 ',
                        'bookmark1 ', 'food_vegetable4 ', 'shampoo2 ', 'nightstand1 ', 'folder4 ', 'folder3 ',
                        'food_vegetable5 ', 'food_carrot4 ', 'glass2 ', 'juice2 ', 'bench1 ', 'comb1 ', 'mousepad1 ',
                        'drawing3 ', 'instrument_piano1 ', 'bowl5 ', 'bed2 ', 'folder5 ', 'food_carrot5 ',
                        'kitchen_cabinet2 ', 'lamp2 ', 'dirt2 ', 'lighter1 ', 'shredder1 ', 'food_snack1 ',
                        'tooth_paste2 ', 'food_pizza2 ', 'food_egg2 ', 'toothbrush4 ', 'knife3 ', 'clothes_underwear2 ',
                        'pot3 ', 'food_lemon1 ', 'arms_right1 ', 'food_egg4 ', 'ice1 ', 'food_fish1 ',
                        'clothes_shirt5 ', 'dresser2 ', 'coffee_cup2 ', 'spoon3 ', 'receipt1 ', 'napkin3 ',
                        'chessboard1 ', 'clothes_dress3 ', 'food_kiwi1 ', 'teeth2 ', 'soap2 ', 'measuring_cup1 ',
                        'coffe_maker3 ', 'box3 ', 'faucet2 ', 'coffee_pot3 ', 'needle1 ', 'clothes_underwear4 ',
                        'toilet2 ', 'box2 ', 'coin3 ', 'food_apple2 ', 'scrabble1 ', 'remote_control2 ',
                        'clothes_socks2 ', 'hands_both3 ', 'coffee_table2 ', 'cleaning_solution2 ', 'oil1 ', 'paper3 ',
                        'box4 ', 'drawing2 ', 'towel_rack1 ', 'toothbrush3 ', 'glass5 ', 'pillow3 ',
                        'instrument_violin1 ', 'clothes_underwear5 ', 'book4 ', 'hands_left1 ', 'paper_towel2 ',
                        'water5 ', 'coffee_pot2 ', 'picture3 ', 'food_noodles2 ', 'clothes_jacket2 ', 'lighting2 ',
                        'food_ice_cream1 ', 'tooth_paste3 ', 'clothes_pants4 ', 'clothes_dress4 ', 'shoe-shine_kit1 ',
                        'clothes_scarf1 ', 'arms_left1 ', 'shoes4 ', 'food_onion2 ', 'basket_for_clothes3 ',
                        'clothes_underwear3 ', 'food_onion3 ', 'napkin4 ', 'fax_machine1 ', 'hands_both2 ', 'mail4 ',
                        'telephone2 ', 'dishwasher2 ', 'coin2 ', 'chair4 ', 'video_game_console2 ', 'food_potato2 ',
                        'thread1 ', 'coin1 ', 'controller2 ', 'mug2 ', 'couch2 ', 'shoes3 ', 'bedroom2 ', 'beer1 ',
                        'homework2 ', 'clothes_socks5 ', 'clothes_socks5 ']
        list_actions = ['wake_kids_up ', 'talk_with_guest ', 'massage ', 'greet_people ', 'say_goodbye ', 'say_goodbye_to_guests_leaving ', \
                        'tuck_kids_in_bed ', 'call_family_member_with_skype_application ', 'make_phone_call ', 'have_quality_family_time ', 'keep_cats_out_of_room ', 'talk_with_friends ', 'wave_at_people_walking_by_through_window ', 'thanksgiving ', 'play_fetch_with_dog ', 'let_bay_learn_how_to_walk ', 'answer_door ', 'pet_cat ', 'meeting ', 'call_mother ', 'give_children_bath ', 'dance_with_kids ', 'have_tea_party ', 'text_friends_while_sitting_on_couch ', 'be_able_to_talk_to_me_about_tv_show_im_watching ', 'speaking_on_headset_in_skype_or_some_form_of_voip_for_business_call ', 'have_conversation_with_boyfriend ', 'visit ', 'have_party ', 'text_friend ', 'family_meetings ', 'ignore_people ', 'entertain ', 'call_client ', 'trick_or_treat ', 'talk_with_your_child_about_their_day ', 'serve_hors_doeurves_to_entering_guest_at_cocktail_party ', 'story_reading_time ', 'read_to_child ', 'greet_guests ', 'talk_to_kids ', 'spend_family_time_playing_games ', 'tell_jokes ', 'getting_in_way_of_guest_trying_to_leave ', 'help_kids_with_homework ', 'talk_on_phone ', 'visit_neighbors ', 'hang_with_friend ', 'make_several_copies_on_printer ', 'get_mail_ready ', 'write_research_paper ', 'write_school_paper ', 'organize_paperwork ', 'write_an_email ', 'do_work_on_computer ', 'order_office_suplies ', 'write_report ', 'sent_email ', 'answer_emails ', 'study_bible ', 'manage_emails ', 'print_out_papers ', 'pay_bills ', 'file_expense_reports ', 'use_computer ', 'grading_papers ', 'update_address_book ', 'mail_signed_letter_to_customer ', 'complete_surveys_on_amazon_turk ', 'research ', 'write_letter ', 'complete_homework ', 'check_email ', 'print_out_document ', 'browse_internet ', 'do_homework ', 'fax_forms_to_doctor ', 'surf_web_for_money_legitimate_making_opportunities ', 'do_taxes ', 'study ', 'read_paper ', 'complete_school_work ', 'file_documents ', 'write_research_papers ', 'prepare_letter_for_mailing ', 'speaking_on_headset_in_skype_or_some_form_of_voip_for_business_call ', 'print_documents ', 'tax_filing ', 'do_work ', 'computer_work ', 'type_up_document ', 'homework ', 'manage_documents ', 'send__email ', 'write_thank_you_notes ', 'transcribe_what_i_say ', 'check_homework ', 'change_shower_curtain ', 'make_up_bed_for_guest_on_couch ', 'do_laundry ', 'paint_ceiling ', 'put_groceries_in_fridge ', 'put_washed_clothes_in_almirah ', 'straighten_pictures_on_wall ', 'arrange_bookshelf ', 're_arrange_office ', 'place_bathmat ', 'change_sheets_and_pillow_cases ', 'place_table ', 'empty_dishwasher_and_fill_dishwasher ', 'decorate ', 'sort_laundry ', 'put_new_books_in_shelves ', 'change_bedding ', 'hang_pictures ', 'wash_clothes ', 'change_toilet_paper_roll ', 'collect_napkin_rings ', 'iron_shirt ', 'sort_clothing_and_care_for_it ', 'lay_tablecloth ', 'turn_night_light_on ', 'clean_dishes ', 'hang_up_poster ', 'straighten_magazines ', 'put_shoes_in_shoe_rack ', 'change_sheets_on_bed ', 'put_dishes_away ', 'pick_toys ', 'bring_leftovers_in_kitchen ', 'decorate_it ', 'put_mail_in_mail_organizer ', 'make_childs_bed ', 'pick_up_dIshes ', 'change_light ', 'make_kids_bed ', 'take_dishes_out_of_dishwasher ', 'organize_cabinet ', 'rotate_stock_in_refrigerator ', 'water_plants ', 'put_away_clean_clothes ', 'light_candles ', 'put_down_decoration ', 'polish_your_shoes ', 'push_all_chairs_in ', 'wash_dishes ', 'change_lightbulb ', 'wash_dishes_with_dishwasher ', 'put_away_groceries ', 'change_toothbrush ', 'place_centerpiece ', 'organize_desk ', 'close_shower_curtain ', 'replace_toothpaste ', 'change_curtains ', 'put_slippers_in_closet ', 'fold_laundry ', 'care_for_houseplants ', 'put_mail_away ', 'arrange_sofa ', 'wash_dishes_by_hand ', 'turn_off_light ', 'set_up_buffet_area ', 'arrange_folders ', 'set_up_table ', 'put_away_dishes ', 'added_meat_to_freezer ', 'fluff_pillow ', 'clean_glasses ', 'straighten_paintings_on_wall ', 'clear_table ', 'put_dvds_on_shelves ', 'rearrange_photo_frames ', 'polish_teas_pot ', 'put_toys_away ', 'make_bed ', 'bring_dirty_plate_to_sink ', 'hold_coats_and_umbrellas ', 'arrange_furniture ', 'unload_dishwasher ', 'organize_panrty ', 'wash_and_clean_all_crystal_in_china_cabinet ', 'load_dishwasher ', 'arrange_shoes ', 'do_dishes ', 'unload_various_items_from_pockets_and_place_them_in_bowl_on_table ', 'pick_up_dirty_dishes ', 'put_alarm_clock_in_bedroom ', 'go_to_sleep ', 'get_ready_for_bed ', 'take_nap ', 'read_them_bedtime_story ', 'wake_me_up ', 'open_front_door ', 'sort_mail ', 'set_up_tv ', 'throw_away_newspaper ', 'organize ', 'fix_broken_toys ', 'Sit ', 'make_tutu ', 'hang_up_car_keys ', 'give_milk_to_cat ', 'wipe_off_shoes ', 'open_curtains ', 'look_at_mirror ', 'teach_them_to_make_their_bed ', 'leave_home ', 'use_laptop ', 'return_phone_calls ', 'put_out_flowers ', 'answer_phone ', 'feed_me ', 'start_computer ', 'pretend_tea ', 'put_in_chair ', 'sit_quietly ', 'put_up_feet ', 'pick_up_obvious_trash ', 'lock_door ', 'open_door ', 'Write ', 'take_coat ', 'tidy ', 'wipe_down_counter ', 'de_wrinkle_sheet ', 'walk_to_room ', 'serve_breakfast ', 'enter_home ', 'throw_shoes ', 'Laugh ', 'annoy_your_dog ', 'raise_blinds ', 'feed_daughter ', 'tummy_time ', 'string_green_beans ', 'watch_fly ', 'get_toilet_paper ', 'put_up_jacket ', 'set_mail_on_table ', 'put_umbrella_away ', 'recycle_items ', 'shut_off_alarm ', 'shredding ', 'make_place_cards ', 'light_candle ', 'serve_meal ', 'look_at_painting ', 'designing_crafts_with_family ', 'whine ', 'pick_up ', 'put_away_blankets ', 'cutting ', 'turn_light_off ', 'enjoy_view_out_window ', 'try_yourself_off ', 'break_table ', 'help_organize_files ', 'get_glass_of_water ', 'bring_me_red_cookbook ', 'take_of_outerwear ', 'serve_food ', 'shut_front_door ', 'hang_car_keys ', 'return_from_store ', 'add_paper_to_printer ', 'set_out_some_snacks_for_toddler ', 'put_down_bags ', 'help_with_quiz_shows ', 'admire_art ', 'get_out_dish ', 'Sew ', 'pet_dog ', 'put_away_clothes ', 'shoe_removal ', 'open_bathroom_window ', 'settle_in ', 'turn_on_computer ', 'pour_cup_of_coffee ', 'keep_cats_inside_while_door_is_open ', 'restock ', 'sew_button ', 'pop_zit ', 'put_away_keys ', 'compute ', 'pick_up_spare_change_on_dresser ', 'plug_in_nightlight ', 'grab_some_juice ', 'Read ', 'switch_on_lamp ', 'put_away_toys ', 'dry_soap_bottles ', 'pick_up_all_trash ', 'bring_food ', 'clean_eggs_from_our_chickens ', 'come_in_and_leave_home ', 'look_out_window ', 'close_dresser_drawer ', 'celebrate_birthday_with_nice_meal ', 'come_home ', 'turn_on_lights ', 'receive_credit_card ', 'put_away_shoes ', 'throw_away_paper ', 'find_dictionary ', 'pack_lunch ', 'celebrate ', 'draw_picture ', 'hair ', 'hang_keys ', 'do_an_art_project ', 'wash_back ', 'card ', 'shop ', 'carry_groceries_to_kitchen ', 'close_curtains ', 'gaze_out_window ', 'open_window ', 'put_away_jackets ', 'build_lego_house ', 'turn_on_light ', 'put_on_purse_put_keys_and_lucky_charms_in_pockets_leave_home ', 'pick_up_toys ', 'put_up_towel ', 'grab_things ', 'hang_up_jacket ', 'write_book ', 'color ', 'pull_up_carpet ', 'write_in_your_diary ', 'straighten_bookshelf ', 'turking ', 'play_with_toys ', 'push_in_dining_room_chair ', 'get_glass_of_milk ', 'walk_through ', 'hang_out ', 'spread_table_with_appropriate_supplies ', 'organize_files ', 'write_story ', 'put_clothes_away ', 'replace_towel ', 'read_text_message ', 'rain_welcome ', 'hide ', 'get_drink ', 'get_some_water ', 'close_door ', 'pick_up_phone ', 'serve_cookies ', 'do_free-style_dance_routine ', 'look_in_refrigerator ', 'draft_home ', 'Wait ', 'sit_in_chair ', 'lay_down_on_floor_and_say_im_rug ', 'feed_dog ', 'push_in_desk_chair ', 'praying ', 'clean_toilet ', 'clean ', 'pull_hair_out_of_drain ', 'scrub_toilet ', 'wash_monitor ', 'wash_table ', 'dust ', 'wipe_room_down_with_lysol ', 'clean_mirror ', 'sweep_hallway_please ', 'wipe_down_sink ', 'polish_table ', 'Vacuum ', 'scrubbing_living_room_tile_floor_is_once_week_activity_for_me ', 'vacuum_carpet ', 'shred_receipts ', 'sweep_and_wipe_table_off_with_rag ', 'clean_bathroom ', 'oil_dining_room ', 'clean_room ', 'clean_fridge ', 'clean_sink ', 'pick_up_cat_hair ', 'clean_floor ', 'mop ', 'flush_toilet ', 'clean_large_jacuzzi_tub ', 'sweep_entrance_hall ', 'clean_screen ', 'clean_kitchen ', 'movie ', 'turn_on_tv ', 'tabletop_game ', 'practice_own_singing ', 'read_book ', 'read_magazine ', 'read_yourself_to_sleep ', 'play_piano ', 'sing_karaoke ', 'play_with_barbies ', 'relax ', 'watch_tv ', 'watch__horror__movie ', 'practice_violin ', 'relax_on_sofa ', 'play_guitar ', 'turn_on_radio ', 'Dance ', 'play_on_laptop ', 'read_newspaper ', 'browse_internet ', 'watch_movie ', 'eat_while_watching_tv ', 'juggling ', 'read_on_sofa ', 'listen_to_music ', 'read_news ', 'play_games ', 'playtime_lunch_with_dolls ', 'social_media__checks ', 'watch_youtube ', 'sing_song ', 'turn_off_tv ', 'play_musical_chairs ', 'playing_video_game ', 'change_tv_channels ', 'Play ', 'physical_therapy ', 'Stretch ', 'do_yoga ', 'workout ', 'make_jello ', 'squeeze_lemon ', 'brew_coffee ', 'make_banana_bread ', 'cook_some_food ', 'prepare_pot_of_boiling_water ', 'slice_apple ', 'make_tomato_sauce ', 'make_peanut_butter_sandwhich ', 'make_eggs ', 'make_iced_coffee ', 'cut_steak ', 'fix_bowl_of_cereal ', 'fix_snack ', 'make__cookies ', 'prepare_sandwitch ', 'fix_sandwhich ', 'prepare_dinner ', 'toast_bread ', 'peel_potatoes ', 'prepare_breakfast ', 'defrost_chicken ', 'make_tea ', 'make_ice_in_ice_trays_for_freezer ', 'make_cereal ', 'make_popcorn ', 'bake ', 'make_toast ', 'cut_bread ', 'keep_an_eye_on_stove_as_something_is_cooking ', 'chop_vegetables ', 'peel_kiwi ', 'eat_breakfast ', 'make_sandwitch ', 'make_coffee ', 'get_ready_to_leave ', 'get_ready_for_day ', 'get_ready_for_school ', 'get_ready_for_work ', 'paint_nails ', 'check_appearance_in_mirror ', 'brush_teeth ', 'wash_face ', 'give_children_bath ', 'broom ', 'give_me_bath ', 'take_off_coat ', 'scrub_bottom_of_feet ', 'go_to_bathroom ', 'take_shower ', 'give_your_child_bath ', 'put_on_foundation ', 'go_pee ', 'shampoo_hair ', 'do_nails ', 'take_shoes_off ', 'style_hair ', 'wash_teeth ', 'bathe ', 'wash_hair ', 'take_jacket_off ', 'tale_off_shoes ', 'wash_hands ', 'do_facial ', 'blow_dry_hair ', 'Shave ', 'put_on_coat_and_shoes ', 'check_self_in_mirror ', 'cut_toenails ', 'use_restroom ', 'put_on_coat ', 'face_washing ', 'wipe_feet ', 'dress_up_and_pretend ', 'take_off_shoes_and_hang_up_coat ', 'put_up_coat ', 'take_off_shoes ', 'hand_washing ', 'brush_hair ', 'dry_hair ', 'put_on_glasses ', 'scrub_face ', 'put_on_your_shoes ', 'hair_dressing ', 'put_shoes_and_coats ', 'apply_lotion ', 'curled_hair ', 'cut_your_hair ', 'use_bathroom ', 'get_dressed ', 'pee ', 'go_to_toilet ', 'toilet ', 'take_bath ', 'change_clothes ', 'deficate ', 'use_toilet ', 'getting_dressed ', 'comb_hair ', 'eat_ice_cream ', 'eat_dinner ', 'dance_for_table_as_we_eat ', 'eat_family_meals ', 'eat_donuts ', 'get_something_to_drink ', 'eat_dessert ', 'Eat ', 'eat_on_fancy_china ', 'have_ice_coffee ', 'Drink ', 'eat_while_watching_tv ', 'eat_breaksfast ', 'have_snack ', 'eat_snacks_and_drink_tea ', 'eat_snacks_and_drink_tea ']

        print(self.choice)
        if str(self.choice) == '1':        ##How can i watch tv
            self.perform_action_simple(list_actions)
        if self.choice == '2':       ## what can i do with coffee coffee cup...
            self.find_use_for_objects(list_steps, list_objects)
        if self.choice == '3':    ## what other objects are related to coffee coffee cup...
            self.related_objects(list_steps, list_objects)
        if self.choice == '4':         ## on what objects can i perform the action or actions
            self.perform_action(list_steps, list_objects)
        if self.choice == '5':                      ## what can i watch if i am in living_room
            self.condition_object(list_steps, list_objects)
        if self.choice == '6':                       ## actions performed on multiple objects
            self.action_related(list_steps, list_objects)
        if self.choice == '7':                       ## actions performed on one object
            self.activity_performed_based_on_object(list_steps, list_objects)
        if self.choice == '8':                      ## return sequence of actions
            self.sequence_of_actions(list_steps, list_objects)
        if self.choice == '9':                      ## return sequence of actions that contain specific objects in order
            self.action_ordered(list_steps, list_objects)

    def perform_action_simple(self, list_actions):
        print("Give me the action you want to perform! If there are more than one separate them by comma :)")
        actions = input()
        actions = actions.lower()
        list_query = actions.split(', ')
        list_query = [entity.replace(' ', '_') for entity in list_query]
        res0 = []
        res1 = []
        for entity in list_query:
            if entity + ' ' in list_actions:
                res0.append(entity)
            else:
                res1.append(entity)
        res2 = []
        for entity in res1:
            hash_choice = {}
            for search in list_actions:
                distance = textdistance.ratcliff_obershelp(entity.replace('_', ' '), search.replace('_', ' '))
                if distance >= 0.6:
                    hash_choice[search] = distance
            if len(hash_choice) > 0:
                print("Unfortunately I do not have " + entity.replace('_', ' ') + " in my KB!")
                print("But for entity " + entity.replace('_', ' ') + " I recommend one of the following actions. They are sorted from left to right")

                hash_choice = sorted(hash_choice.items(), key=lambda kv: kv[1], reverse=True)
                list_temp_actions = []
                for key in hash_choice:
                    list_temp_actions.append(str(key[0]))
                print(list_temp_actions)
                print("Give a number if you want some of these.")
                choice = input()
                res2.append(list_temp_actions[int(choice) - 1])
                print(res2)
            else:
                print("I could not find results for " + entity.replace('_', ' '))
        res = res2 + res0
        try:
            for j in res:
                f = open('SPARQL_Query.txt', 'w')
                SPARQL = """
                            PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                            PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                            PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                            SELECT DISTINCT ?instance ?comment WHERE{ ?instance a :""" + j + """; \
                                                                                rdfs:comment ?comment}"""
                f.write(SPARQL)
                f.close()
                object_ontology = ontology_household_environment('Alex', res)
                sparql_results_comment = object_ontology.ontology_parsing()
                sparql_results_comment = self.Remove(sparql_results_comment)

                for entity in range(len(sparql_results_comment)):
                    sparql_results_comment[entity] = sparql_results_comment[entity].replace(")", "").replace("   ", " --> ")

                f = open('SPARQL_Query.txt', 'w')
                SPARQL = """
                            PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                            PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                            PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                            SELECT DISTINCT ?instance ?comment WHERE{ ?instance a :""" + j + """}"""
                f.write(SPARQL)
                f.close()
                object_ontology = ontology_household_environment('Alex', res)
                sparql_results = object_ontology.ontology_parsing()
                sparql_results = self.Remove(sparql_results)
                while True:
                    print("Do you want me to explain them all or a specific one?")
                    print(sparql_results_comment)
                    print("Tell me All otherwise Specific!")
                    choice_explain = input()
                    if choice_explain.lower() == "All".lower():
                        for entity in sparql_results:
                            f = open('SPARQL_Query.txt', 'w')
                            SPARQL = """
                                    PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                                    PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                                    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                                    SELECT ?label ?object WHERE{ :""" + entity + \
                                     """ :listOfSteps ?list. ?list rdf:rest*/rdf:first ?step.
                                    OPTIONAL{?step :object ?object .}
                                   ?step :step_type ?label}
                                    """
                            f.write(SPARQL)
                            f.close()
                            object_ontology_final = ontology_household_environment('Alex', res)
                            sparql_results_final = object_ontology_final.ontology_parsing()
                            sparql_results_final = self.Remove(sparql_results_final)
                            del sparql_results_final[-1]
                            print(entity + "\n")
                            for entity_step in sparql_results_final:
                                list_entity = entity_step.split(' ')
                                length = len(entity_step.split(' '))
                                if length == 2:
                                    print(list_entity[0])
                                else:
                                    print(list_entity[2] + ' ' + list_entity[0])
                            print("\n")

                        break
                    elif choice_explain.lower() == "Specific".lower():
                        print("Which one do you want me to explain? Give me a number")
                        specific_choice = input()
                        f = open('SPARQL_Query.txt', 'w')
                        SPARQL = """
                                    PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                                    PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                                    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                                    SELECT ?label ?object WHERE{ :""" + sparql_results[int(specific_choice) - 1] + \
                                    """ :listOfSteps ?list. ?list rdf:rest*/rdf:first ?step.
                                    ?step :object ?object .
                                    ?step :step_type ?label}
                                    """
                        f.write(SPARQL)
                        f.close()
                        object_ontology = ontology_household_environment('Alex', res)
                        sparql_results = object_ontology.ontology_parsing()
                        sparql_results = self.Remove(sparql_results)
                        del sparql_results[-1]
                        for entity in sparql_results:
                            print(entity)
                        break
                    else:
                        print("I could not understand what you want")
                        break
        except Exception:
            exit()

    def find_use_for_objects(self, list_steps, list_objects):                                     ## How to use three different products
        print("Give me the objects for which you want me to find sequence of actions! If there are more than one seperate them by comma :)")
        actions = input()
        list_query = actions.split(', ')
        object_annotator = main_NLP(list_query, list_objects)
        res = object_annotator.find_list()
        print(res)
        try:
            SPARQL = """
                        PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                        PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                        SELECT ?instance WHERE{
                        ?int1 rdfs:subClassOf :Activities.
                        ?in1 rdfs:subClassOf ?int1 .
                        ?instance a ?in1;     
                             :listOfSteps ?list1.                         
                     """
            f = open('SPARQL_Query.txt', 'w')
            help = ""
            k = 1
            for entity in res:
                something = " ?list1 rdf:rest*/rdf:first ?step" + str(k) + " . ?step" \
                            + str(k) + " :object :" + entity + " . \n"
                help = help + something
                k = k + 1
            f.write(SPARQL + help + "}")
            f.close()
            object_ontology = ontology_household_environment('Alex', res)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
            print("\n")
        except Exception:
            print("\n")



    def related_objects(self, list_steps, list_objects):              ##What other objects are related to s set of objects
        print("Give me the objects for which you want me to find other objects! If there are more than one seperate them by comma :)")
        actions = input()
        list_query = actions.split(', ')
        object_annotator = main_NLP(list_query, list_objects)
        res = object_annotator.find_list()
        print(res)
        try:
            f = open("SPARQL_Query.txt", "w")
            SPARQL = """
                        PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                        PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                        SELECT DISTINCT ?object WHERE {
                                ?instance1 :listOfSteps ?list .
                                ?list rdf:rest*/rdf:first ?element.
                                ?element :object ?object {
                        SELECT DISTINCT ?instance1 WHERE{
                     """
            k = 1
            help = ""
            for entity in res:
                something = "?int" + str(k) + " rdfs:subClassOf :Activities. " + "?in" + str(k) + " rdfs:subClassOf " + "?int" + str(k) + "." \
                        " ?instance1 a ?in" + str(k) + ";" + " :listOfSteps ?list" + str(k) + "." + "?list" + str(k) + " rdf:rest*/rdf:first " \
                        + " ?step" + str(k) + "." + " ?step" + str(k) + " :object :" + entity + " . \n"
                help = help + something
                k = k + 1
            SPARQL = SPARQL + help + " } }"
            help = ""
            for entity in res:
                something = " FILTER (?object != :" + entity + " )"
                help = help + something
            SPARQL = SPARQL + help + "}"
            f.write(SPARQL)
            f.close()
            object_ontology = ontology_household_environment('Alex', res)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
        except Exception:
            print("\n")


    def perform_action(self, list_steps, list_objects):
        print("Give me the actions you want me to search for! If there are more than one seperate them by comma :)")
        actions = input()
        list_query = actions.split(', ')
        res = []
        for entity in list_query:
            for action in list_steps:
                distance = textdistance.ratcliff_obershelp(entity.replace('_', ' '), action.replace('_', ' '))
                if distance >= 0.7:
                    res.append(action)
        res = self.Remove(res)
        ####Newwwww######
        if len(res) < len(list_query):
            for entity in res:
                list_query.remove(entity.replace(' ', ''))
            res1 = []
            for act in list_query:
                action_web = Action(list_query)
                res0 = action_web.find_actions()
                if res0 != []:
                    print("For " + act + " I have to recommend")
                    print("Do you want any, if Yes give a number of the list you see")
                    choice = input()
                    res1.append(res0[int(choice) - 1])
                else:
                    print("Sorry for " + act + " I have nothing to recommend, I will proceed with out it")
        res = res + res1
        #####Newwwwwww#####
        print(res)

        try:
            f = open("SPARQL_Query.txt", "w")
            SPARQL = """
                         PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                         PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                         PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                         SELECT DISTINCT ?object WHERE {
                     """
            help = ""
            k = 0
            for entity in res:
                something = " ?instance" + str(k) + " :step_type :" + entity + ";  :object ?object."
                help = help + something
                k = k + 1
            SPARQL = SPARQL + help + "}"
            f.write(SPARQL)
            f.close()
            object_ontology = ontology_household_environment('Alex', res)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
        except Exception:
            print("\n")

    def condition_object(self, list_steps, list_objects):
        res0 = []
        res1 = []
        print("Give me the action! If there are more than one seperate them by comma :)")
        actions = input()
        print("Give me the condition!")
        condition = input()
        list_query = actions.split(', ')
        """
         for word in list_query:
             if word + ' ' in list_steps:
                 res0.append(word)
                 continue
         """
        #### Newwwwww ####
        for entity in list_query:
            for action in list_steps:
                distance = textdistance.ratcliff_obershelp(entity.replace('_', ' '), action.replace('_', ' '))
                if distance >= 0.7:
                    res0.append(action)
        res0 = self.Remove(res0)
        if len(res0) < len(list_query):
            for entity in res0:
                list_query.remove(entity.replace(' ', ''))
            res1 = []
            for act in list_query:
                action_web = Action(list_query)
                res = action_web.find_actions()
                if res != []:
                    print("For " + act + " I have to recommend")
                    print("Do you want any, if Yes give a number of the list you see\n")
                    choice = input()
                    res1.append(res[int(choice) - 1])
                else:
                    print("Sorry for " + act + " I have nothing to recommend, I will proceed with out it\n")
        res0 = res0 + res1
        #### Newwwwwww ####

        list_query = condition.split(', ')
        list_query = [condition.replace(' ', '_') for condition in list_query]
        object_annotator = main_NLP(list_query, list_objects)
        res1 = object_annotator.find_list_with_condition()
        print(res0)
        print(res1)
        try:
            f = open("SPARQL_Query.txt", "w")
            SPARQL = """
                         PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                         PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                         PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                         SELECT DISTINCT ?object WHERE {
                         ?int rdfs:subClassOf :Activities . 
                         ?in rdfs:subClassOf ?int.
                         ?instance a ?in;
                                    :listOfSteps ?list.
                         ?list rdf:rest*/rdf:first ?step. ?step :object :""" + res1[0] + " . "
            help = ""
            k = 0
            for entity in res0:
                something = "?list rdf:rest*/rdf:first ?step" + str(k) + ". " + "?step" + str(k) + " :step_type :" + entity + ";" \
                ":object ?object."
                k = k + 1
                help = something+ help
            SPARQL = SPARQL + help + "}"
            f.write(SPARQL)
            f.close()
            object_ontology = ontology_household_environment('Alex', res0 + res1)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
        except Exception:
            print("\n")


    def action_related(self, list_steps, list_objects):
        print("Give me the objects for which you want me to find actions! If there are more than one seperate them by comma :)")
        actions = input()
        list_query = actions.split(', ')
        object_annotator = main_NLP(list_query, list_objects)
        res = object_annotator.find_list()
        print(res)
        try:
            f = open("SPARQL_Query.txt", "w")
            SPARQL = """
                        PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                        PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                        SELECT DISTINCT ?object WHERE {
                        ?instance :listOfSteps ?list .
                        ?list rdf:rest*/rdf:first ?element.
                        ?element :step_type ?object{
                        SELECT DISTINCT ?instance WHERE{
                    """
            k = 1
            help = ""
            for entity in res:
                something = " ?int" + str(k) + " rdfs:subClassOf :Activities . " + " ?in" + str(k) + " rdfs:subClassOf   ?int" + str(k) + "." \
                    + " ?instance a ?in" + str(k) + "; :listOfSteps ?list" + str(k) + ". ?list" + str(k) + " rdf:rest*/rdf:first ?step" + str(k) + "." \
                    + " ?step" + str(k) + " :object :" + entity + ". "
                help = help + something
                k = k + 1
            SPARQL = SPARQL + help + "}}}"
            f.write(SPARQL)
            f.close()
            object_ontology = ontology_household_environment('Alex', res)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
        except Exception:
            print("\n")

    def activity_performed_based_on_object(self, list_steps, list_objects):             ##Given an object what actions can we perform on it
        print("Give me the object for which you want me to find an activity! If there are more than one seperate them by comma :)")
        actions = input()
        list_query = actions.split(', ')
        object_annotator = main_NLP(list_query, list_objects)
        res = object_annotator.find_list()
        print(res)
        try:
            f = open("SPARQL_Query.txt", "w")
            SPARQL = """
                        PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                        PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                        SELECT DISTINCT ?instance WHERE{
                    """
            help = ""
            for entity in res:
                something = " ?instance :object :" + entity + " ."
                help = help + something
            SPARQL = SPARQL + help + " }"
            f.write(SPARQL)
            f.close()
            object_ontology = ontology_household_environment('Alex', res)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
        except Exception:
            print("\n")

    def sequence_of_actions(self, list_steps, list_objects):
        print("Give a sequence of actions you want me to expand")
        actions = input()
        list_query = actions.split(', ')
        print(list_query)
        try:
            for entity in list_query:
                f = open('SPARQL_Query.txt', 'w')
                SPARQL = """
                        PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                        PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                        PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                        SELECT ?label ?object WHERE{ :""" + entity + """ :listOfSteps ?list. ?list rdf:rest*/rdf:first ?step.
                        ?step :object ?object .
						?step :step_type ?label}
                        """
                f.write(SPARQL)
                f.close()
                object_ontology = ontology_household_environment('Alex', list_query)
                sparql_results = object_ontology.ontology_parsing()
                sparql_results = self.Remove(sparql_results)
                print(sparql_results)
                del sparql_results[-1]
                for step in sparql_results:
                    print(step)
        except Exception:
            print("\n")

    def action_ordered(self, list_steps, list_objects):
        print("Give a sequence of objects in the order you want to appear in the sequence of actions, seperated by comma")
        objects = input()
        list_query = objects.split(', ')
        object_annotator = main_NLP(list_query, list_objects)
        res = object_annotator.find_list()
        print(res)
        try:
            f = open('SPARQL_Query.txt', 'w')
            SPARQL = """
                    PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                    PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                    PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                    SELECT ?instance1 WHERE{ ?int1 rdfs:subClassOf :Activities .
                                            ?in1 rdfs:subClassOf   ?int1 .
                                            ?instance1 a ?in1;
                                                        :listOfSteps ?list1.
                    """
            help = ""
            k = 0
            for entity in res:
                something = " ?list1  rdf:rest*/rdf:first ?step" + str(k) + ". ?step" + str(k) + " :object :" + entity + ". "
                help = help + something
                k = k + 1
            SPARQL = SPARQL + help + "}"
            f.write(SPARQL)
            f.close()
            object_ontology = ontology_household_environment('Alex', res)
            sparql_results = object_ontology.ontology_parsing()
            sparql_results = self.Remove(sparql_results)
            print(sparql_results)
            comments = []
            for j in sparql_results:
                f = open('SPARQL_Query.txt', 'w')
                SPARQL = """
                             PREFIX :  <http://www.owl-ontologies.com/VirtualHome.owl#>
                             PREFIX rdfs:  <http://www.w3.org/2000/01/rdf-schema#>
                             PREFIX rdf: <http://www.w3.org/1999/02/22-rdf-syntax-ns#>
                             SELECT DISTINCT ?instance ?comment WHERE{:""" + j + """ rdfs:comment ?comment}"""
                f.write(SPARQL)
                f.close()
                object_ontology = ontology_household_environment('Alex', sparql_results)
                sparql_results_comment = object_ontology.ontology_parsing()
                sparql_results_comment = self.Remove(sparql_results_comment)
                if len(sparql_results_comment) > 0:
                    comments.append(sparql_results_comment[0].replace(")", ""))
                else:
                    comments.append("No comment found")
            for entity in range(len(sparql_results)):
                print(sparql_results[entity] + "-->" + comments[entity])
        except Exception:
            print("\n")



