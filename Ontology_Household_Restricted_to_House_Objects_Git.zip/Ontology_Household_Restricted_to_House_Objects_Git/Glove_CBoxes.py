from sklearn.feature_extraction.text import TfidfVectorizer
from nltk.stem.porter import PorterStemmer
from nltk.tokenize import word_tokenize
from sklearn.metrics.pairwise import cosine_similarity

class Glove_CB():


    def __init__(self, perceived, common, non_common, weights):
        self.perceived = perceived
        self.common = common
        self.non_common = non_common
        self.weights = weights

    def tokenize(self, text):
        tokens = word_tokenize(text)
        stems = []
        for item in tokens: stems.append(PorterStemmer().stem(item))
        return stems

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def glove_build(self):
        bad_chars = [';', ':', '!', "*", "@", "\n", "%", "?", ".", "-", "_", "&", "'s", ",", ";", "(", ")", "[", "]",
                    "{", "}", "~", "\r", "+", "$", "1", "0", "2", "3", "4", "5", "6", "7", "8", "9", "\""]

        if self.perceived != []:
            for char in bad_chars:
                self.perceived[0] = self.perceived[0].replace(str(char), "")



        hash_common = {}
        len1 = len(self.common)
        if len1 > 0:
            for property in self.common:
                ant = property
                for char in bad_chars:
                    property = property.replace(str(char), "")
                hash_common[property] = self.common[ant]



        hash_noncommon = {}
        len2 = len(self.non_common)
        if len2 > 0:
            for property in self.non_common:
                ant = property
                for char in bad_chars:
                    property = property.replace(str(char), "")
                hash_noncommon[property] = self.non_common[ant]



        tfidf_common = {}
        for common in hash_common:
            text = self.perceived
            text.append(common)
            text_tfidf = [" ".join(self.tokenize(txt.lower())) for txt in text]
            vectorizer_common = TfidfVectorizer()
            matrix_common = vectorizer_common.fit_transform(text_tfidf).todense()
            common_tfidf = cosine_similarity(matrix_common[0], matrix_common[1])
            common_box = hash_common[common][0]
            common_box.append(common_tfidf[0][0])
            if tfidf_common.get(hash_common[common][0][0]) == None:
                tfidf_common.setdefault(hash_common[common][0][0], []).append(common_box)
            else:
                tfidf_common[hash_common[common][0][0]].append(common_box)


        tfidf_Notcommon = {}
        for not_common in hash_noncommon:
            text = self.perceived
            text.append(not_common)
            text_tfidf = [" ".join(self.tokenize(txt.lower())) for txt in text]
            vectorizer_not_common = TfidfVectorizer()
            matrix_not_common = vectorizer_not_common.fit_transform(text_tfidf).todense()
            not_common_tfidf = cosine_similarity(matrix_not_common[0], matrix_not_common[1])
            common_not_box = hash_noncommon[not_common][0]
            common_not_box.append(not_common_tfidf[0][0])
            if tfidf_Notcommon.get(hash_noncommon[not_common][0][0]) == None:
                tfidf_Notcommon.setdefault(hash_noncommon[not_common][0][0], []).append(common_not_box)
            else:
                tfidf_Notcommon[hash_noncommon[not_common][0][0]].append(common_not_box)


        tfidf_common_weights = {}
        for entity in tfidf_common:
            k = 0
            for entity1, entity2 in self.weights:
                if entity == entity1:
                    k = entity2
            tfidf_common[entity][0].append(k)
            if tfidf_common_weights.get(entity) == None:
                tfidf_common_weights.setdefault(entity, []).append(tfidf_common[entity])
            else:
                tfidf_common_weights[entity].append(tfidf_common[entity])

        tfidf_NotCommon_weights = {}
        for entity in tfidf_Notcommon:
            k = 0
            for entity1, entity2 in self.weights:
                if entity == entity1:
                    k = entity2
            tfidf_Notcommon[entity][0].append(k)
            if tfidf_NotCommon_weights.get(entity) == None:
                tfidf_NotCommon_weights.setdefault(entity, []).append(tfidf_Notcommon[entity])
            else:
                tfidf_NotCommon_weights[entity].append(tfidf_Notcommon[entity])


        final_common = {}
        for entity in tfidf_common_weights:
            final_score_common = 1/(tfidf_common_weights[entity][0][0][2] + 1) + tfidf_common_weights[entity][0][0][3] + \
                                 tfidf_common_weights[entity][0][0][4]
            if final_common.get(entity) == None:
                final_common.setdefault(entity, []).append((tfidf_common_weights[entity][0][0][1], final_score_common))
            else:
                final_common[entity].append((tfidf_common_weights[entity][0][0][1], final_score_common))

        final_notcommon = {}
        for entity in tfidf_NotCommon_weights:
            final_score_common = 1/(tfidf_NotCommon_weights[entity][0][0][2] + 1) + tfidf_NotCommon_weights[entity][0][0][3] + \
                                 tfidf_NotCommon_weights[entity][0][0][4]
            if final_notcommon.get(entity) == None:
                final_notcommon.setdefault(entity, []).append((tfidf_NotCommon_weights[entity][0][0][1], final_score_common))
            else:
                final_notcommon[entity].append((tfidf_NotCommon_weights[entity][0][0][1], final_score_common))

        for entity in final_common:
            if entity in final_notcommon:
                del final_notcommon[entity]
        return final_common, final_notcommon

