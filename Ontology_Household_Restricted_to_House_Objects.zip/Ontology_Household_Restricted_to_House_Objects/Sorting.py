

class sorting_final():

    def __init__(self, common, not_common, perceived):
        self.common = common
        self.not_common = not_common
        self.perceived = perceived

    def Remove(self, duplicate):
        final = []
        for num in duplicate:
            if num not in final:
                final.append(num)
        return final

    def display(self):
        self.common.update(self.not_common)  # Merge the two hashmaps
        list_score = []
        for value in self.common:
            list_score.append((value, self.common[value][0][0], self.common[value][0][1]))
        list_score = sorted(list_score, key=lambda x: x[2], reverse=True)

        hash_display = {}
        for value in list_score:
            val = value[1].replace('/r/', '')
            if hash_display.get(val) == None:
                hash_display.setdefault(val, []).append((value[0], value[2]))
            else:
                hash_display[val].append((value[0], value[2]))

        for property in hash_display:
            help_display = ""
            for entity in hash_display[property]:
                help_display = help_display + str(entity[0]).capitalize() + " score: " + str(round(entity[1], 5)) + ". "
            #print(str(self.perceived[0]) + " is " + str(property) + " " + help_display)
        return hash_display
