In this folder we have the evaluation sheets for our framework.


First Evaluation folder contains the files that were used for the first scale of evaluation. 
Inside First Evaluation folder we have 5 subfolders:

(1) Crowd_Source_Answers_CS_NCS has the answers to the questions from people that fall into the category
related to Computer Science and Non related to Computer Science.
(2) Crowd_Source_Answers_W_B-M_P has the answers to the questions from people that fall into the category
Workers (without University education), Bachelor/Master Students, and PhD students.
(3) Excels_Samples_First contains the samples of answers that the user were given to evaluate how satisfied they are
with the answer of our framework.
(4) Results_First are the results of the first evaluation.


Second Evaluation folder contains the files that were used for the second scale of evaluation. 
Inside Second Evaluation folder we have 6 subfolders and a file:

(1) Sampling contains the gold standard dataset that was gathered from 5 individuals (not in the first evaluation).
The information is gathered in ResultsNew.txt file.
(2) ComputerScience file has the answers that people related to computer science picked from the ResultsNew.txt file
for each question.
(3) NonComputerScience file has the answers that people non related to computer science picked from the ResultsNew.txt file
for each question.
(4) Worker file has the answers that people without university education picked from the ResultsNew.txt file
for each question.
(5) Bachelor-Master file has the answers that people with bachelor or master education picked from the ResultsNew.txt file
for each question.
(6) PhD file has the answers that people which are PhD students picked from the ResultsNew.txt file
for each question.
(7) Finally Results.txt has the scores that our framework achieved with respect to the answer that people from (2)-(6) picked.


